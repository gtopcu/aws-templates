module.exports = {
  testEnvironment: "node"
}
